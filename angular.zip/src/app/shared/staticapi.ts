export const bnyData = {
    topNavi: [
        {
            label: 'Dashboard'
        },
        {
            label: 'workflow'
        }
    ]
};
