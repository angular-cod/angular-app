import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { InquiryComponent } from './inquiry/inquiry.component';
import { DemographicsComponent } from './demographics/demographics.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [InquiryComponent, DemographicsComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule.forRoot()
  ]
})
export class DashboardModule { }
