import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-inquiry',
  templateUrl: './inquiry.component.html',
  styleUrls: ['./inquiry.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
