import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-compliance',
  templateUrl: './compliance.component.html',
  styleUrls: ['./compliance.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ComplianceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
