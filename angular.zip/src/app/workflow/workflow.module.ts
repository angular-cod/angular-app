import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WorkflowRoutingModule } from './workflow-routing.module';
import { ComplianceComponent } from './compliance/compliance.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [ComplianceComponent],
  imports: [
    CommonModule,
    WorkflowRoutingModule,
    SharedModule.forRoot()
  ]
})
export class WorkflowModule { }
