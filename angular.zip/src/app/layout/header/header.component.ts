import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {HeaderService} from './header.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  topNavi;
  constructor(
    private StaticData: HeaderService
  ) { }
  getHeaderData(): void {
    this.StaticData.getHeaderNavi().subscribe((res: any) => {
      console.log(res);
      this.topNavi = res.topNavi;
    });
  }
  ngOnInit(): void {
    this.getHeaderData();
  }

}
