import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { bnyData } from '../../shared/staticapi';
@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  constructor(
    private http: HttpClient
  ) { }

  getHeaderNavi(): Observable<any> {
    return of(bnyData);
  }
}
